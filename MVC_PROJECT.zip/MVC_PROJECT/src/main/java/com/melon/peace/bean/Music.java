package com.melon.peace.bean;

public class Music {
	private String musicNo;
	private String vocal;
	private String title;
	private String releaseComp;
	private String releaseDate;
	
	public String getMusicNo() {
		return musicNo;
	}
	public void setMusicNo(String musicNo) {
		this.musicNo = musicNo;
	}
	public String getVocal() {
		return vocal;
	}
	public void setVocal(String vocal) {
		this.vocal = vocal;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getReleaseComp() {
		return releaseComp;
	}
	public void setReleaseComp(String releaseComp) {
		this.releaseComp = releaseComp;
	}
	public String getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}
}
