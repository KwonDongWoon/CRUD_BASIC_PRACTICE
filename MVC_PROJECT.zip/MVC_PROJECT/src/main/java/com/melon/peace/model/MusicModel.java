package com.melon.peace.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.melon.peace.bean.Music;
import com.melon.peace.util.OracleConnection;

import jakarta.servlet.http.HttpServletRequest;

public class MusicModel {
	public static void writeMusic(HttpServletRequest req) {
	    Connection conn = null;
	    PreparedStatement stmt = null;
	    try {
	        conn = OracleConnection.getConnection();
	        conn.setAutoCommit(false);

	        StringBuffer sb = new StringBuffer();
	        sb.append("INSERT INTO MUSIC (MUSIC_NO, TITLE, VOCAL) ");
	        sb.append("VALUES (SEQ_MUSIC.NEXTVAL, ?, ?)");
	        stmt = conn.prepareStatement(sb.toString());
	        stmt.setObject(1, req.getParameter("title"));
	        stmt.setObject(2, req.getParameter("vocal"));
	        stmt.executeUpdate();
	        stmt.close();

	        sb = new StringBuffer();
	        sb.append("INSERT INTO MUSIC_DETAIL (MUSIC_DETAIL_NO, RELEASE_COMP, RELEASE_DATE, MUSIC_NO) ");
	        sb.append("VALUES (SEQ_MUSIC_DETAIL.NEXTVAL, ?, ?, SEQ_MUSIC.CURRVAL)");
	        stmt = conn.prepareStatement(sb.toString());
	        stmt.setObject(1, req.getParameter("releaseComp"));
	        stmt.setObject(2, req.getParameter("releaseDate"));
	        stmt.executeUpdate();

	        conn.commit();
	    } catch (Exception e) {
	        e.printStackTrace();
	        try {
	            if (conn != null) conn.rollback();
	        } catch (SQLException se) {
	            se.printStackTrace();
	        }
	    } finally {
	        try {
	            if (stmt != null) stmt.close();
	       //     if (conn != null) conn.close();
	        } catch (SQLException se) {
	            se.printStackTrace();
	        }
	    }
	}
	public static List<Music> listMusic(HttpServletRequest req){
	    Connection conn = null;
	    Statement stmt = null;
	    ResultSet rs = null;
	    List<Music> musicList = new ArrayList<>();
	    try {
	        conn = OracleConnection.getConnection();
	        stmt = conn.createStatement();
	        StringBuffer sb = new StringBuffer();
	        sb.append(" SELECT M.MUSIC_NO ");
	        sb.append("    ,M.TITLE ");
	        sb.append("    ,M.VOCAL ");
	        sb.append("    ,D.RELEASE_COMP ");
	        sb.append("    ,TO_CHAR(D.RELEASE_DATE, 'YYYY/MM/DD') AS RELEASE_DATE ");
	        sb.append(" FROM MUSIC M ");
	        sb.append(" INNER JOIN MUSIC_DETAIL D ");
	        sb.append(" ON M.MUSIC_NO = D.MUSIC_NO ");
	        sb.append(" ORDER BY D.RELEASE_DATE DESC ");
	        rs = stmt.executeQuery(sb.toString());

	        while (rs.next()) {
	            Music music = new Music();
	            music.setMusicNo(rs.getString("MUSIC_NO"));
	            music.setVocal(rs.getString("VOCAL"));
	            music.setTitle(rs.getString("TITLE"));
	            music.setReleaseComp(rs.getString("RELEASE_COMP"));  // 아마 오타인 것 같아요
	            music.setReleaseDate(rs.getString("RELEASE_DATE"));  // releaseDate로 저장해야할 듯
	            musicList.add(music);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (rs != null) rs.close();
	            if (stmt != null) stmt.close();
	           // if (conn != null) conn.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    return musicList;
	}
	public static void deleteMusic(String musicNo) {
	    Connection conn = null;
	    PreparedStatement pstmt = null;

	    try {
	        conn = OracleConnection.getConnection();
	        conn.setAutoCommit(false); // 트랜잭션 시작

	        // 2. 그 다음 MUSIC 테이블에서 삭제
	        String sqlMusic = "DELETE FROM MUSIC WHERE MUSIC_NO = ?";
	        pstmt = conn.prepareStatement(sqlMusic);
	        pstmt.setString(1, musicNo);
	        pstmt.executeUpdate();

	        conn.commit(); // 성공 시 커밋
	    } catch (Exception e) {
	        try {
	            if (conn != null) conn.rollback(); // 실패 시 롤백
	        } catch (SQLException se) {
	            se.printStackTrace();
	        }
	        e.printStackTrace();
	    } finally {
	        try {
	            if (pstmt != null) pstmt.close();
//	            if (conn != null) conn.close();
	        } catch (SQLException se) {
	            se.printStackTrace();
	        }
	    }
	}
	public static void updateMusic(String musicNo, String title, String vocal, String releaseComp, String releaseDate) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = OracleConnection.getConnection();
            conn.setAutoCommit(false);  // 트랜잭션 시작

            // 1. MUSIC 테이블 업데이트
            String sqlMusic = "UPDATE MUSIC SET TITLE = ?, VOCAL = ? WHERE MUSIC_NO = ?";
            pstmt = conn.prepareStatement(sqlMusic);
            pstmt.setString(1, title);
            pstmt.setString(2, vocal);
            pstmt.setString(3, musicNo);
            pstmt.executeUpdate();
            pstmt.close();

            conn.commit();  // 성공 시 커밋

        } catch (Exception e) {
            e.printStackTrace();
            try {
                if (conn != null) conn.rollback();  // 실패 시 롤백
            } catch (SQLException se) {
                se.printStackTrace();
            }
        } finally {
            try {
                if (pstmt != null) pstmt.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
    }
}
	


