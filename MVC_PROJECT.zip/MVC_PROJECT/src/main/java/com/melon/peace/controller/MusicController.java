package com.melon.peace.controller;

import java.io.IOException;
import com.melon.peace.model.MusicModel;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class MusicController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String uri = req.getRequestURI();
        
        if (uri.contains("music_write_form.melon")) {
            req.getRequestDispatcher("/WEB-INF/view/music/music_write_form.jsp").forward(req, resp);
        }
        
        if (uri.contains("music_write.melon")) {
            MusicModel.writeMusic(req);
            resp.sendRedirect("/MVC_PROJECT/");
        }
        
        if (uri.contains("music_list.melon")) {
            req.setAttribute("musicList", MusicModel.listMusic(req));
            req.getRequestDispatcher("/WEB-INF/view/music/music_list.jsp").forward(req, resp);
        }

        // 삭제 처리
        if (uri.contains("delete_music.melon")) {
            String musicNo = req.getParameter("musicNo");
            MusicModel.deleteMusic(musicNo);
            resp.sendRedirect("/MVC_PROJECT/music_list.melon");
        }
        
        // 수정디테일폼 이동하기 값 모두 가져와서
        if (uri.contains("update_detail_music.melon")) {
        	req.setAttribute("musicList", MusicModel.listMusic(req));
        	req.getRequestDispatcher("/WEB-INF/view/music/music_list_edit.jsp").forward(req, resp);
        }

        // 수정 처리 (update_music.melon)
        if (uri.contains("update_music.melon")) {
            // 수정된 값들을 받아서 처리
            String[] selectedMusicNos = req.getParameterValues("selectedMusicNo");
            System.out.println(selectedMusicNos);
            if (selectedMusicNos != null) {
                for (String musicNo : selectedMusicNos) {
                    String newTitle = req.getParameter("title_" + musicNo);
                    String newVocal = req.getParameter("vocal_" + musicNo);
                    String newReleaseComp = req.getParameter("releaseComp_" + musicNo);
                    String newReleaseDate = req.getParameter("releaseDate_" + musicNo);
                    
                    MusicModel.updateMusic(musicNo, newTitle, newVocal, newReleaseComp, newReleaseDate);
                }
            }

            resp.sendRedirect("/MVC_PROJECT/music_list.melon");
        }
    }
}
